import pandas as pd


archivo_original = "data/registros_dashboard.xlsx"

archivo_prueba = "data/prueba_dashboard.xlsx"


df = pd.read_excel(
    archivo_original,
    dtype={"cedula": str}
)


prueba = df.head(5)


prueba.to_excel(
    archivo_prueba,
    index=False
)


print("✅ Archivo creado:")
print(archivo_prueba)

print("\nRegistros:")
print(prueba)