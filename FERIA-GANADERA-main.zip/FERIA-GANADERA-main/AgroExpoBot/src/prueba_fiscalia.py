from src.fiscalia.buscador import BuscadorFiscalia
from src.fiscalia.parser import extraer_noticias


def main():

    cedula = "0912823135"


    buscador = BuscadorFiscalia()


    try:

        buscador.iniciar()


        print(
            "🔎 Buscando cédula:",
            cedula
        )


        texto = buscador.buscar_por_cedula(
            cedula
        )


        print(
            "\n========== TEXTO OBTENIDO =========="
        )

        print(
            texto[:2000]
        )


        noticias = extraer_noticias(
            texto,
            cedula
        )


        print(
            "\n========== PARSEANDO RESULTADO =========="
        )


        print(
            "Noticias encontradas:",
            len(noticias)
        )


        for n in noticias:


            print(
                "\n-------------------------"
            )


            print(
                "Noticia:",
                n.get(
                    "numero_noticia"
                )
            )


            print(
                "Fecha:",
                n.get(
                    "fecha"
                )
            )


            print(
                "Lugar:",
                n.get(
                    "lugar"
                )
            )


            print(
                "Delito:",
                n.get(
                    "delito"
                )
            )


            print(
                "Sujetos:"
            )


            for s in n.get(
                "sujetos",
                []
            ):


                print(
                    " ",
                    s.get("cedula"),
                    "-",
                    s.get("nombre"),
                    "-",
                    s.get("rol")
                )


        print(
            "\n========== FIN =========="
        )


    finally:

        buscador.cerrar()



if __name__ == "__main__":

    main()