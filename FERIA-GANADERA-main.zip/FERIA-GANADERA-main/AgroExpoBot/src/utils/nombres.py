def nombre_valido_para_busqueda(nombre):

    if not nombre:
        return False


    palabras = nombre.strip().split()


    # Nombre completo:
    # mínimo nombre + dos apellidos
    if len(palabras) >= 3:

        return True


    return False