import re
from playwright.sync_api import sync_playwright
from actualizar_excel import actualizar_excel

BASE_URL = "https://core-it.ec/registroexpo/agroexpo2026.php?view=registros&page={}"


def obtener_ultima_pagina(page):
    """Obtiene el número de la última página del dashboard."""

    page.goto(BASE_URL.format(1))
    page.wait_for_load_state("networkidle")

    enlaces = page.locator(".pagination a")

    ultima = 1

    print("\n========== BUSCANDO ÚLTIMA PÁGINA ==========")

    for i in range(enlaces.count()):

        href = enlaces.nth(i).get_attribute("href")

        if href:

            m = re.search(r"page=(\d+)", href)

            if m:

                numero = int(m.group(1))

                if numero > ultima:
                    ultima = numero

    print("Última página:", ultima)

    return ultima


def leer_pagina(page, numero):
    """Lee todos los registros de una página."""

    print(f"\nLeyendo página {numero}...")

    page.goto(BASE_URL.format(numero))

    page.wait_for_load_state("networkidle")

    filas = page.locator("#registrosTable tbody tr")

    registros = []

    print("Registros encontrados:", filas.count())

    for i in range(filas.count()):

        columnas = filas.nth(i).locator("td")

        datos = []

        for j in range(columnas.count()):

            datos.append(
                columnas.nth(j).inner_text().strip()
            )

        registro = {

            "cedula": datos[0] if len(datos) > 0 else "",
            "nombre": datos[1] if len(datos) > 1 else "",
            "empresa": datos[2] if len(datos) > 2 else "",
            "cargo": datos[3] if len(datos) > 3 else "",
            "celular": datos[4] if len(datos) > 4 else "",
            "correo": datos[5] if len(datos) > 5 else "",
            "fecha_ingreso": datos[6] if len(datos) > 6 else "",
            "estado": datos[7] if len(datos) > 7 else "",
            "asistencia": datos[8] if len(datos) > 8 else ""

        }

        registros.append(registro)

    return registros


def iniciar():

    with sync_playwright() as p:

        navegador = p.chromium.launch(headless=False)

        pagina = navegador.new_page()

        ultima = obtener_ultima_pagina(pagina)

        todos = []

        for numero in range(ultima, 0, -1):

            registros = leer_pagina(pagina, numero)

            todos.extend(registros)

        print("\n===================================")
        print("TOTAL DE PERSONAS:", len(todos))
        print("===================================")

        actualizar_excel(todos)

        navegador.close()


if __name__ == "__main__":
    iniciar()