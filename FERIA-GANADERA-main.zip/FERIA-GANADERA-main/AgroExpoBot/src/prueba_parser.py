from src.fiscalia.parser import extraer_noticias


texto = """
PEGA AQUI EL RESULTADO QUE TE DIO FISCALIA
"""


datos = extraer_noticias(
    texto,
    "0912823135"
)


for x in datos:
    print(x)