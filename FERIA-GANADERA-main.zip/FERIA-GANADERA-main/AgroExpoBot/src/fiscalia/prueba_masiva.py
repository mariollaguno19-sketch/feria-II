import pandas as pd

from src.fiscalia.proceso import iniciar_proceso


iniciar_proceso()