import re



# ==========================================
# NORMALIZAR CEDULA
# ==========================================

def normalizar_cedula(cedula):

    if not cedula:
        return ""

    return (
        str(cedula)
        .replace(".", "")
        .strip()
    )



# ==========================================
# EXTRAER NOTICIAS
# ==========================================

def extraer_noticias(
    texto,
    cedula=None
):

    noticias = []


    bloques = re.split(
        r"NOTICIA DEL DELITO Nro\.",
        texto
    )


    for bloque in bloques[1:]:


        noticia = {

            "numero_noticia":"",
            "fecha":"",
            "lugar":"",
            "delito":"",
            "sujetos":[]

        }



        # --------------------------
        # NUMERO
        # --------------------------

        numero = re.search(
            r"(\d{10,20})",
            bloque
        )

        if numero:

            noticia["numero_noticia"] = numero.group(1)




        # --------------------------
        # FECHA
        # --------------------------

        fecha = re.search(
            r"FECHA\s+(\d{4}-\d{2}-\d{2})",
            bloque
        )

        if fecha:

            noticia["fecha"] = fecha.group(1)




        # --------------------------
        # LUGAR
        # --------------------------

        lugar = re.search(
            r"LUGAR\s+(.+?)\s+FECHA",
            bloque,
            re.S
        )

        if lugar:

            noticia["lugar"] = (
                lugar.group(1)
                .replace("\n"," ")
                .strip()
            )




        # --------------------------
        # DELITO
        # --------------------------

        delito = re.search(
            r"DELITO:\s*(.+)",
            bloque
        )


        if delito:

            noticia["delito"] = (
                delito.group(1)
                .split("\n")[0]
                .strip()
            )




        # --------------------------
        # SUJETOS
        # --------------------------
        #
        # Captura:
        #
        # 0912823135 NOMBRE DENUNCIANTE
        # 0000000000 NN SOSPECHOSO NO RECONOCIDO
        #
        # sin limitar roles
        #


        sujetos = re.findall(

            r"(\d{10})\s+(.+?)\s+("
            r"DENUNCIANTE|"
            r"SOSPECHOSO NO RECONOCIDO|"
            r"SOSPECHOSO|"
            r"INVESTIGADO|"
            r"PROCESADO|"
            r"ACUSADO|"
            r"IMPUTADO|"
            r"DENUNCIADO|"
            r"RESPONSABLE|"
            r"PRESUNTO RESPONSABLE|"
            r"CONDUCTOR|"
            r"PARTICIPE|"
            r"PARTÍCIPE|"
            r"VICTIMA|"
            r"VÍCTIMA|"
            r"TESTIGO|"
            r"AFECTADO|"
            r"NN"
            r")",

            bloque,
            re.I

        )



        for ced, nombre, rol in sujetos:


            noticia["sujetos"].append(

                {

                    "cedula":
                        ced.strip(),


                    "nombre":
                        nombre.strip(),


                    "rol":
                        rol.strip().upper()

                }

            )



        noticias.append(
            noticia
        )


    return noticias




# ==========================================
# BUSCAR PERSONA
# ==========================================

def obtener_persona_buscada(
    noticia,
    cedula_busqueda
):


    cedula_busqueda = normalizar_cedula(
        cedula_busqueda
    )


    for sujeto in noticia.get(
        "sujetos",
        []
    ):


        if normalizar_cedula(
            sujeto.get("cedula","")
        ) == cedula_busqueda:


            return sujeto



    return None




# ==========================================
# ROLES
# ==========================================

ROLES_RELEVANTES = [

    "SOSPECHOSO",
    "INVESTIGADO",
    "PROCESADO",
    "ACUSADO",
    "IMPUTADO",
    "DENUNCIADO",
    "RESPONSABLE",
    "PRESUNTO RESPONSABLE",
    "AUTOR",
    "PARTICIPE",
    "CONDUCTOR"

]




def es_rol_relevante(rol):


    rol = str(rol).upper()


    for r in ROLES_RELEVANTES:

        if r in rol:

            return True


    return False