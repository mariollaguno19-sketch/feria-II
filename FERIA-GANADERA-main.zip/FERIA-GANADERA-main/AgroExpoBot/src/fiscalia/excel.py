import os
import pandas as pd
from datetime import datetime


# ==============================
# RUTAS
# ==============================

BASE_DIR = os.path.dirname(
    os.path.dirname(
        os.path.dirname(
            os.path.abspath(__file__)
        )
    )
)


DATA_DIR = os.path.join(
    BASE_DIR,
    "data"
)


os.makedirs(
    DATA_DIR,
    exist_ok=True
)


RESULTADOS = os.path.join(
    DATA_DIR,
    "resultados_fiscalia.xlsx"
)


HISTORIAL = os.path.join(
    DATA_DIR,
    "historial_consultas.xlsx"
)



# ==============================
# NORMALIZAR CEDULA
# ==============================

def normalizar_cedula(cedula):

    if pd.isna(cedula):
        return ""

    return str(
        cedula
    ).replace(
        ".",
        ""
    ).zfill(10)



# ==============================
# VERIFICAR CONSULTA
# ==============================

def ya_consultado(cedula):

    cedula = normalizar_cedula(
        cedula
    )


    if not os.path.exists(HISTORIAL):

        return False


    historial = pd.read_excel(
        HISTORIAL,
        dtype={
            "cedula":str
        }
    )


    if "cedula" not in historial.columns:

        return False


    historial["cedula"] = (
        historial["cedula"]
        .astype(str)
        .str.zfill(10)
    )


    return cedula in historial["cedula"].values



# ==============================
# REGISTRAR HISTORIAL
# ==============================

def registrar_consulta(
    cedula,
    nombre,
    metodo="FINALIZADO"
):


    registro = pd.DataFrame(
        [
            {

                "cedula":
                    normalizar_cedula(
                        cedula
                    ),

                "nombre":
                    nombre,

                "metodo":
                    metodo,

                "fecha_consulta":
                    datetime.now()
                    .strftime(
                        "%Y-%m-%d %H:%M:%S"
                    )

            }
        ]
    )



    if os.path.exists(HISTORIAL):

        historial = pd.read_excel(
            HISTORIAL,
            dtype={
                "cedula":str
            }
        )


        historial["cedula"] = (
            historial["cedula"]
            .astype(str)
            .str.zfill(10)
        )


        registro = pd.concat(
            [
                historial,
                registro
            ],
            ignore_index=True
        )



    registro.drop_duplicates(
        subset=[
            "cedula"
        ],
        keep="last",
        inplace=True
    )



    registro.to_excel(
        HISTORIAL,
        index=False
    )


    print(
        "📝 Consulta registrada en historial"
    )



# ==============================
# GUARDAR RESULTADOS
# ==============================

def guardar_resultados(resultados):


    columnas = [

        "numero_noticia",
        "cedula_dashboard",
        "nombre_dashboard",
        "metodo_busqueda",
        "fecha",
        "lugar",
        "delito",
        "rol_persona_busqueda",
        "cedula_sujeto",
        "nombre_sujeto",
        "observacion",
        "fecha_consulta"

    ]



    if resultados:


        filas = []


        for r in resultados:


            filas.append(

                {

                "numero_noticia":
                    r.get(
                        "numero_noticia",
                        ""
                    ),


                "cedula_dashboard":
                    normalizar_cedula(
                        r.get(
                            "cedula_busqueda",
                            ""
                        )
                    ),


                "nombre_dashboard":
                    r.get(
                        "nombre_dashboard",
                        ""
                    ),


                "metodo_busqueda":
                    r.get(
                        "metodo_busqueda",
                        ""
                    ),


                "fecha":
                    r.get(
                        "fecha",
                        ""
                    ),


                "lugar":
                    r.get(
                        "lugar",
                        ""
                    ),


                "delito":
                    r.get(
                        "delito",
                        ""
                    ),


                "rol_persona_busqueda":
                    r.get(
                        "rol_persona_busqueda",
                        ""
                    ),


                "cedula_sujeto":
                    normalizar_cedula(
                        r.get(
                            "cedula_sujeto",
                            ""
                        )
                    ),


                "nombre_sujeto":
                    r.get(
                        "nombre_sujeto",
                        ""
                    ),


                "observacion":
                    r.get(
                        "observacion",
                        ""
                    ),


                "fecha_consulta":
                    datetime.now()
                    .strftime(
                        "%Y-%m-%d %H:%M:%S"
                    )

                }

            )


        nuevo = pd.DataFrame(
            filas
        )


    else:


        nuevo = pd.DataFrame(
            columns=columnas
        )



    if os.path.exists(RESULTADOS):


        actual = pd.read_excel(
            RESULTADOS,
            dtype={
                "cedula_dashboard":str
            }
        )


        nuevo = pd.concat(
            [
                actual,
                nuevo
            ],
            ignore_index=True
        )



    if not nuevo.empty:


        nuevo.drop_duplicates(
            subset=[
                "numero_noticia",
                "cedula_dashboard"
            ],
            keep="last",
            inplace=True
        )



    nuevo.to_excel(
        RESULTADOS,
        index=False
    )


    print(
        "✅ Resultados Fiscalía guardados"
    )