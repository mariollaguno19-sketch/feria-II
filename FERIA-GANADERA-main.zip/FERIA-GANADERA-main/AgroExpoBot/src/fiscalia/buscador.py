from playwright.sync_api import sync_playwright


URL = "https://www.fiscalia.gob.ec/accesibilidad/consulta-de-noticias-del-delito/"


class BuscadorFiscalia:


    def __init__(self):

        self.playwright = None
        self.browser = None
        self.page = None



    def iniciar(self):

        self.playwright = sync_playwright().start()


        self.browser = self.playwright.chromium.launch(
            headless=False
        )


        self.page = self.browser.new_page()


        self.page.goto(URL)


        self.page.wait_for_timeout(3000)


        print(
            "✅ Fiscalía abierta correctamente"
        )




    def obtener_iframe(self):

        for frame in self.page.frames:


            if "gestiondefiscalias" in frame.url:

                return frame


        raise Exception(
            "No se encontró iframe Fiscalía"
        )




    def limpiar_busqueda(self, frame):

        try:

            frame.click(
                "#btn_limpiar_campo"
            )

            frame.wait_for_timeout(
                1000
            )

        except:

            pass




    def buscar_por_cedula(
        self,
        cedula
    ):


        print(
            "🔎 Buscando cédula:",
            cedula
        )


        frame = self.obtener_iframe()


        self.limpiar_busqueda(
            frame
        )


        campo = frame.locator(
            "#pwd"
        )


        campo.fill(
            cedula
        )


        frame.click(
            "#btn_buscar_denuncia"
        )


        frame.wait_for_timeout(
            4000
        )


        return frame.inner_text(
            "body"
        )





    def buscar_por_nombre(
        self,
        nombre
    ):


        print(
            "🔎 Buscando nombre:",
            nombre
        )


        frame = self.obtener_iframe()


        self.limpiar_busqueda(
            frame
        )


        campo = frame.locator(
            "#pwd"
        )


        campo.fill(
            nombre
        )


        frame.click(
            "#btn_buscar_denuncia"
        )


        frame.wait_for_timeout(
            4000
        )


        return frame.inner_text(
            "body"
        )





    def cerrar(self):


        if self.browser:

            self.browser.close()


        if self.playwright:

            self.playwright.stop()