import pandas as pd
import re


from src.fiscalia.buscador import BuscadorFiscalia

from src.fiscalia.parser import extraer_noticias


from src.fiscalia.excel import (
    ya_consultado,
    registrar_consulta,
    guardar_resultados
)


from src.utils.config import DASHBOARD_EXCEL

from src.utils.nombres import nombre_valido_para_busqueda

from src.fiscalia.comparador_nombres import comparar_nombres




ROLES_IGNORADOS = [
    "DENUNCIANTE",
    "VICTIMA",
    "VÍCTIMA",
    "TESTIGO",
    "PERJUDICADO",
    "AFECTADO"
]



ROLES_VALIDOS = [
    "SOSPECHOSO",
    "INVESTIGADO",
    "PROCESADO",
    "ACUSADO",
    "IMPUTADO",
    "DENUNCIADO",
    "AUTOR",
    "PARTICIPE",
    "RESPONSABLE",
    "CAUSANTE",
    "INVOLUCRADO"
]



DELITOS_TRANSITO = [
    "TRANSITO",
    "TRÁNSITO",
    "ACCIDENTE",
    "CHOQUE",
    "COLISION",
    "COLISIÓN",
    "DAÑOS MATERIALES"
]





def limpiar_delito(delito):

    if not delito:
        return ""

    return re.sub(
        r"\(\d+\)",
        "",
        str(delito)
    ).strip()





def delito_transito(delito):

    delito = limpiar_delito(delito).upper()


    for palabra in DELITOS_TRANSITO:

        if palabra in delito:
            return True


    return False





def rol_valido(rol):

    rol = str(rol).upper()


    for r in ROLES_VALIDOS:

        if r in rol:
            return True


    return False






def analizar_noticias(
    noticias,
    cedula,
    nombre,
    metodo
):


    resultados = []


    print(
        "Noticias analizadas:",
        len(noticias)
    )



    for noticia in noticias:


        delito = noticia.get(
            "delito",
            ""
        )


        if delito_transito(delito):

            print(
                "⚠ Delito tránsito ignorado:",
                limpiar_delito(delito)
            )

            continue





        for sujeto in noticia.get(
            "sujetos",
            []
        ):


            cedula_sujeto = str(
                sujeto.get(
                    "cedula",
                    ""
                )
            ).strip()



            nombre_sujeto = str(
                sujeto.get(
                    "nombre",
                    ""
                )
            ).strip()



            rol = str(
                sujeto.get(
                    "rol",
                    ""
                )
            ).upper()





            if any(
                x in rol
                for x in ROLES_IGNORADOS
            ):

                continue





            coincide = False



            # =========================
            # COINCIDENCIA POR CEDULA
            # =========================

            if cedula_sujeto == cedula:

                coincide = True





            # =========================
            # COINCIDENCIA POR NOMBRE
            # SOLO SI TIENE NOMBRE COMPLETO
            # =========================


            elif nombre_valido_para_busqueda(nombre):


                if comparar_nombres(
                    nombre,
                    nombre_sujeto,
                    minimo_palabras=3
                ):

                    print(
                        "✅ Coincidencia nombre:",
                        nombre_sujeto
                    )


                    coincide = True





            if coincide and rol_valido(rol):


                print(
                    "🔥 ENCONTRADO:",
                    nombre_sujeto,
                    "-",
                    rol
                )



                noticia["es_relevante"] = True

                noticia["rol_persona_busqueda"] = rol

                noticia["cedula_busqueda"] = cedula

                noticia["metodo_busqueda"] = metodo

                noticia["nombre_dashboard"] = nombre

                noticia["delito"] = limpiar_delito(
                    delito
                )


                resultados.append(
                    noticia
                )


                break



    return resultados






def procesar_persona(
    buscador,
    cedula,
    nombre
):


    print("\n------------------------------")

    print(
        "Cédula:",
        cedula
    )

    print(
        "Nombre:",
        nombre
    )



    print(
        "🔎 Buscando por cédula..."
    )



    texto = buscador.buscar_por_cedula(
        cedula
    )



    noticias = extraer_noticias(
        texto
    )



    resultados = analizar_noticias(
        noticias,
        cedula,
        nombre,
        "CEDULA"
    )



    if resultados:

        return resultados





    if nombre_valido_para_busqueda(nombre):


        print(
            "⚠ Sin resultados relevantes por cédula"
        )


        print(
            "🔎 Buscando por nombre..."
        )



        texto = buscador.buscar_por_nombre(
            nombre
        )


        noticias = extraer_noticias(
            texto
        )


        return analizar_noticias(
            noticias,
            cedula,
            nombre,
            "NOMBRE"
        )



    else:


        print(
            "❌ Nombre incompleto, no se busca por nombre"
        )



    return []








def iniciar_proceso():


    personas = pd.read_excel(
        DASHBOARD_EXCEL,
        dtype={
            "cedula":str
        }
    )



    print("==============================")

    print(
        "TOTAL PERSONAS:",
        len(personas)
    )

    print("==============================")



    buscador = BuscadorFiscalia()



    try:


        buscador.iniciar()



        for _, persona in personas.iterrows():



            cedula = str(
                persona["cedula"]
            ).strip()



            nombre = str(
                persona["nombre"]
            ).strip()



            print(
                "\nPROCESANDO"
            )



            if ya_consultado(cedula):

                print(
                    "⏭ Ya consultado"
                )

                continue





            resultados = procesar_persona(
                buscador,
                cedula,
                nombre
            )





            if resultados:


                guardar_resultados(
                    resultados
                )


            else:

                print(
                    "Sin coincidencias relevantes"
                )





            registrar_consulta(
                cedula,
                nombre,
                "FINALIZADO"
            )




    finally:

        buscador.cerrar()





if __name__ == "__main__":

    iniciar_proceso()